DROP DATABASE IF EXISTS gameshop;
	CREATE DATABASE gameshop;
USE gameshop;


DROP TABLE IF EXISTS catalogo;
CREATE TABLE catalogo (
	codice_catalogo int(15) not null primary key
    );
    DROP TABLE IF EXISTS utente;
CREATE TABLE utente (
	id_utente varchar(25) not null primary key,
  email varchar(25) not null ,
  codice_catalogo int(10),
  password varchar(32) not null,
  
  foreign key(codice_catalogo) REFERENCES catalogo(codice_catalogo),
  UNIQUE KEY email(email)
);
DROP TABLE IF EXISTS città;
CREATE TABLE città (
id_città varchar(30) not null primary key,
nome_città varchar(25) not null
);
DROP TABLE IF EXISTS Dati_Anagrafici;
CREATE TABLE Dati_anagrafici (
id_utente varchar(25) not null ,
id_città varchar (30) not null,
Nome varchar(25) not null,
Cognome varchar (25) not null,
Indirizzo varchar (50) not null,
telefono1 varchar (15) not null,
telefono2 varchar(15),

foreign key (id_utente) references utente (id_utente),
foreign key(id_città) references città(id_città)
);

DROP TABLE IF EXISTS provincia;
CREATE TABLE provincia (
id_provincia varchar (25) not null primary key,
Nome_provincia varchar(25) not null
);


DROP TABLE IF EXISTS Rubrica_indirizzi;
CREATE TABLE Rubrica_indirizzi (
Id_Indirizzo smallint not null,
id_utente varchar(25) not null,
id_città varchar(30) not null,
nome varchar(25) not null,
cognome varchar(25) not null,
indirizzo varchar(50) not null,
foreign key(id_utente) references utente (id_utente),
foreign key (id_città) references città(id_città)
);
DROP TABLE IF EXISTS cap;
CREATE TABLE cap (
id_cap int(15) not null primary key,
id_città varchar (30) not null,
id_provincia varchar (30) not null,
nome_cap int(5) not null,
foreign key (id_città) references città (id_città),
foreign key (id_provincia) references provincia(id_provincia)
);

DROP TABLE IF EXISTS ordine;
CREATE TABLE ORDINE (
numero_ordine varchar(30) not null primary key,
id_utente varchar(25) not null,
importo_totale decimal(20,2) not null,
numero_articoli int (15) not null,
foreign key (id_utente) REFERENCES utente (id_utente)
);
DROP TABLE IF EXISTS fornitore;
CREATE TABLE FORNITORE (
partita_iva varchar(11) not  null primary key,
nome		varchar(250) not null,
indirizzo	varchar(250) not null
);

DROP TABLE IF EXISTS articoli;
CREATE TABLE articoli (
codice_articoli varchar (30) not null primary key,
codice_catalogo int (10) not null,
descrizione varchar(250) not null,
prezzo 		decimal(15,2) not null,
nomi 		varchar(250) not null,
tipologia_articoli 	varchar(250) not null,
foreign key(codice_catalogo) REFERENCES CATALOGO (codice_catalogo)
);
DROP TABLE IF EXISTS compongono;
CREATE TABLE compongono (
codice_articoli varchar (30) not null,
numero_ordine VARCHAR (30) not null,
quantità varchar(30) not null,
foreign key(codice_articoli) REFERENCES ARTICOLI(codice_articoli),
foreign key(numero_ordine) REFERENCES ORDINE(numero_ordine)
);
DROP TABLE IF EXISTS SONO_FORNITI_DA;
CREATE TABLE SONO_FORNITI_DA	(
codice_articoli varchar(30) not null,
partita_iva	varchar(11) not null,
foreign key(codice_articoli) REFERENCES ARTICOLI (codice_articoli),
foreign key(partita_iva) REFERENCES FORNITORE(partita_iva)
);



DROP TABLE IF EXISTS STANDARD;
CREATE TABLE STANDARD(
id_spedizione int (10) not null primary key auto_increment,
numero_ordine varchar (30) not null,
data_spedizione date,
costo	decimal(10,2) not null,
foreign key(numero_ordine) REFERENCES ORDINE(numero_ordine)
);
DROP TABLE IF EXISTS VELOCE;
CREATE TABLE VELOCE (
id_spedizione int (10) not null primary key,
numero_ordine varchar (30) not null,
data_spedizione date,
costo decimal(10,2) not null,
foreign key (numero_ordine) REFERENCES ORDINE(numero_ordine)
);
DROP TABLE IF EXISTS PAGAMENTO;
CREATE TABLE PAGAMENTO (
id_pagamento int(15) not null primary key,
numero_ordine varchar (30) not null,
importo_pagamento decimal (15,2) not null,
foreign key(numero_ordine) REFERENCES ORDINE (numero_ordine)
);
DROP TABLE IF EXISTS CARTA;
CREATE TABLE CARTA(
numero_di_carta varchar(25) not null primary key,
id_pagamento int(10) not null,
dati_intestatario varchar(25) not null,
foreign key(id_pagamento) REFERENCES PAGAMENTO(id_pagamento)
);
DROP TABLE IF EXISTS CONTANTI;
CREATE TABLE CONTANTI(
id_pagamento int (10) not null,
foreign key(id_pagamento) REFERENCES PAGAMENTO(id_pagamento)
);
DROP TABLE IF EXISTS BONIFICO;
CREATE TABLE BONIFICO (
iban varchar (27) not null primary key,
id_pagamento int(10) not null,
causale varchar(144) not null,
dati_intestatario varchar(50) not null,
foreign key(id_pagamento) REFERENCES PAGAMENTO(id_pagamento)
);
DROP TABLE IF EXISTS FATTURA;
CREATE TABLE FATTURA (
id_fattura int(15) not null primary key,
id_pagamento int (10) not null,
data	date,
foreign key(id_pagamento) REFERENCES PAGAMENTO(id_pagamento)
);
/*OPERAZIONE 1*/
INSERT INTO CATALOGO  value('1');
INSERT INTO UTENTE (id_utente,codice_catalogo,email,password) values ('1','1','MARIOROSSI@LIBERO.IT',md5('MARIOROSSI'));
INSERT INTO UTENTE (id_utente,codice_catalogo,email,password) values ('2', '1','LUIGIROSSI@GMAIL.COM',md5('LUIGIROSSI'));
INSERT INTO UTENTE (id_utente,codice_catalogo,email,password) values ('3','1','LORENZOROSSI@GMAIL.COM',md5('LOROSSI90'));
INSERT INTO UTENTE (id_utente,codice_catalogo,email,password) values ('4','1','DARIOROSSI@LIBERO.IT',md5('DARIOXXX'));
INSERT INTO UTENTE (id_utente,codice_catalogo,email,password) values ('5','1','BOBOLI@TISCALI.IT',md5('BOBOHBOHK'));
INSERT INTO UTENTE (id_utente,codice_catalogo,email,password) values ('6','1','MICH67@LIBERO.IT',md5('MICH7890'));
/*******************************************/

INSERT INTO città (id_città, nome_città) values ('1','Calitri');
INSERT INTO città (id_città, nome_città) values ('2','AVELLINO');
INSERT INTO città (id_città, nome_città) values ('3','BISACCIA');
INSERT INTO città (id_città, nome_città) values ('4','FISCIANO');
INSERT INTO città (id_città, nome_città) values ('5','ANGRI');
INSERT INTO città (id_città, nome_città) values ('6','POMPEI');
/*id tramite nome*/
INSERT INTO città (id_città, nome_città) values ('Calitri','Calitri');
INSERT INTO città (id_città, nome_città) values ('AVELLINO','AVELLINO');
INSERT INTO città (id_città, nome_città) values ('BISACCIA','BISACCIA');
INSERT INTO città (id_città, nome_città) values ('FISCIANO','FISCIANO');
INSERT INTO città (id_città, nome_città) values ('ANGRI','ANGRI');
INSERT INTO città (id_città, nome_città) values ('POMPEI','POMPEI');
/* A SCELTA DELL'UTENTE DOPO LA CREAZIONE DELL'ACCOUNT*/

INSERT INTO DATI_ANAGRAFICI (id_utente, id_città, nome, cognome, indirizzo,telefono1,telefono2) values ('1','1', 'MARIO','ROSSI','VIA ROSSI','082535996',NULL);
INSERT INTO DATI_ANAGRAFICI (id_utente, id_città, nome, cognome, indirizzo,telefono1,telefono2) values ('2','3', 'LUIGI','ROSSI','VIA MAZZINI 22','024677891','3544701814');
INSERT INTO DATI_ANAGRAFICI (id_utente, id_città, nome, cognome, indirizzo,telefono1,telefono2) values ('3','6', 'LORENZO','ROSSI','VIA TEDESCO 77','047535997',null);
INSERT INTO DATI_ANAGRAFICI (id_utente, id_città, nome, cognome, indirizzo,telefono1,telefono2) values ('4','2', 'DARIO','ROSSI','VIA SABA 44','027895997',null);
INSERT INTO DATI_ANAGRAFICI (id_utente, id_città, nome, cognome, indirizzo,telefono1,telefono2) values ('5','4', 'BOB','VENIERO','VIA MANCINI 25','083766997',null);
INSERT INTO DATI_ANAGRAFICI (id_utente, id_città, nome, cognome, indirizzo,telefono1,telefono2) values ('6','5', 'MICHELE','FIORENTINI','VIA CIRCUMVALLAZIONE 36','082457896','374221819');
/*************************************************************/

INSERT INTO provincia (id_provincia, nome_provincia) values ('1', 'Avellino');
INSERT INTO provincia (id_provincia, nome_provincia) values ('2', 'SALERNO');
INSERT INTO provincia (id_provincia, nome_provincia) values ('3', 'NAPOLI');
INSERT INTO provincia (id_provincia, nome_provincia) values ('4', 'CASERTA');
INSERT INTO provincia (id_provincia, nome_provincia) values ('5', 'BENEVENTO');
INSERT INTO provincia (id_provincia, nome_provincia) values ('6', 'POTENZA');
INSERT INTO provincia (id_provincia, nome_provincia) values ('7', 'MATERA');
INSERT INTO provincia (id_provincia, nome_provincia) values ('8', 'ROMA');

/* A SCELTA DELL'UTENTE DOPO LA CREAZIONE DELL'ACCOUNT*/

INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo)  values ('1','1','4','Luca','Russo','VIA PAPA XII');
INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo)  values ('2','1','2','Bob','Russo','Piazza Macello');
INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo) values ('3','2','3','Antonio','Zeppa','VIA Romulea 44');
INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo) values ('4','3','5','Lorenzo','Bravi','Corso Roma 55');
INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo) values ('5','4','6','Mariano','Rauso','Corso Vittorio Emanuele 33');
INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo) values ('6','6','4','Michele','Atlas','VIA Papa Giovanni XII');
INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente, id_città, nome, cognome, indirizzo) values ('7', '5', '5', 'Lorenzo', 'Maffei', 'Via Mancini 33'); 
/* RIEMPIE TABELLA CAP*/

INSERT INTO CAP (id_cap, id_città, id_provincia, nome_cap) VALUES ('1','1','1','83045');
INSERT INTO CAP (id_cap, id_città, id_provincia, nome_cap) VALUES ('2','2','1','83100');
INSERT INTO CAP (id_cap, id_città, id_provincia, nome_cap) VALUES ('3','3','1','83044');
INSERT INTO CAP (id_cap, id_città, id_provincia, nome_cap) VALUES ('4','4','2','84084');
INSERT INTO CAP (id_cap, id_città, id_provincia, nome_cap) VALUES ('5','5','2','84012');
INSERT INTO CAP (id_cap, id_città, id_provincia, nome_cap) VALUES ('6','6','3','80045');
/***********************************************/
/***********POPOLAMENTO ARTICOLI DENTRO CATALOGO*/

INSERT INTO ARTICOLI (codice_articoli, codice_catalogo, descrizione, prezzo, nomi, tipologia_articoli) VALUES ('01','1', 'Call Of Duty per Ps4, videogioco in edizione digitale', '40.00', 'Call Of Duty Ps4', 'Articolo non in Offerta');
INSERT INTO ARTICOLI (codice_articoli, codice_catalogo, descrizione, prezzo, nomi, tipologia_articoli) VALUES ('02','1', 'Grand Theft Auto V, continuano le storie, questa volta in maniera differente, con Franklin e Trevor', '70.00', 'Grand Theft Auto V per Xbox 360','Articolo Non in Offerta');
INSERT INTO ARTICOLI (codice_articoli, codice_catalogo, descrizione, prezzo, nomi, tipologia_articoli) VALUES ('03','1', 'Playstation 4, console innovativa, più potenza per eseguire i tuoi giochi preferiti', '400.00', 'Console PlayStation 4', 'Articolo Non in Offerta');
INSERT INTO ARTICOLI (codice_articoli, codice_catalogo, descrizione, prezzo, nomi, tipologia_articoli) VALUES ('04','1', 'Un bundle esclusivo, una playstation 4 con incluso il gioco grand theft auto 5, una potenza e bellezza unica, inclusa alla convenienza', '450.00','Bundle ps4+gta5', 'Pacchetto combo in offerta');
/*********************************************************/
/****************POPOLAMENTO FORNITORI*/

INSERT INTO FORNITORE(partita_iva, nome, indirizzo) VALUES ('05628696789', 'Videogiochi & C.', 'Via portuense 34');
INSERT INTO FORNITORE(partita_iva, nome, indirizzo) VALUES ('07742158866', 'Fun & Liberty Games', 'Via Garibaldi 77');
/**************************forniti da****************/

INSERT INTO SONO_FORNITI_DA(codice_articoli, partita_iva) VALUES ('01', '05628696789');
INSERT INTO SONO_FORNITI_DA(codice_articoli, partita_iva) VALUES ('02', '07742158866');
INSERT INTO SONO_FORNITI_DA(codice_articoli, partita_iva) VALUES ('03', '05628696789');
INSERT INTO SONO_FORNITI_DA(codice_articoli, partita_iva) VALUES ('04', '05628696789');
/***************INSERIMENTO ORDINE*/

INSERT INTO ordine(numero_ordine, id_utente, importo_totale, numero_articoli) VALUES ('1','1', '480.00', '3');
INSERT INTO compongono(codice_articoli, numero_ordine, quantità) VALUES ('03','1','1');
INSERT INTO compongono(codice_articoli, numero_ordine, quantità) VALUES ('01','1','2');
INSERT INTO ordine(numero_ordine, id_utente, importo_totale, numero_articoli) VALUES ('2','6', '110.00', '2');
INSERT INTO compongono(codice_articoli, numero_ordine, quantità) VALUES ('01','2','1');
INSERT INTO compongono(codice_articoli, numero_ordine, quantità) VALUES ('02','2','1');
INSERT INTO ordine(numero_ordine, id_utente, importo_totale, numero_articoli) VALUES ('3','2', '450.00', '1');
INSERT INTO compongono(codice_articoli, numero_ordine, quantità) VALUES ('04','3','1');

INSERT INTO ORDINE (numero_ordine, id_utente, importo_totale, numero_articoli) values ('4','6', '70.00','1');
INSERT INTO compongono (codice_articoli, numero_ordine, quantità)	values('02','4','1');
/********************INSERIMENTO SPEDIZIONE*/

INSERT INTO STANDARD (ID_SPEDIZIONE, numero_ordine, data_spedizione, costo) VALUES ( '001', '1', '2021-01-01', '10.00');
INSERT INTO VELOCE (id_spedizione, numero_ordine, data_spedizione, costo) VALUES ('002', '2', '2021-02-02', '15.50');
INSERT INTO VELOCE (id_spedizione, numero_ordine, data_spedizione, costo) VALUES ('003', '3', '2021-02-06', '15.50');

INSERT INTO STANDARD (ID_SPEDIZIONE, numero_ordine, data_spedizione, costo) VALUES ( '4', '4', '2020-06-10', '10.00');

/**********************SCELTA PAGAMENTO********************/

INSERT INTO PAGAMENTO(id_pagamento, numero_ordine, importo_pagamento) VALUES ('001','1','490.00');
INSERT INTO PAGAMENTO(id_pagamento, numero_ordine, importo_pagamento) VALUES ('002','2','125.50');
INSERT INTO PAGAMENTO(id_pagamento, numero_ordine, importo_pagamento) VALUES ('003','3','465.50');
INSERT INTO CARTA (numero_di_carta, id_pagamento, dati_intestatario) VALUES  ('4533561089705612','001','MARIO ROSSI');
INSERT INTO CONTANTI ( id_pagamento) VALUES  ('002');
INSERT INTO BONIFICO (IBAN, ID_PAGAMENTO, CAUSALE, DATI_INTESTATARIO) VALUES ( 'IT2635847941568742651480310', '03', 'Pagamento articoli', 'Luigi Rossi');

INSERT INTO PAGAMENTO(id_pagamento, numero_ordine, importo_pagamento) VALUES ('4','4','80.00');
INSERT INTO CARTA (numero_di_carta, id_pagamento, dati_intestatario) VALUES  ('4540749689709687','4','MIchele R.');

/****comporterà inserimento fattura*/

INSERT INTO FATTURA (ID_FATTURA, ID_PAGAMENTO, DATA) VALUES ('01','1', '2021-01-02');
INSERT INTO FATTURA (ID_FATTURA, ID_PAGAMENTO, DATA) VALUES ('02','2', '2021-02-03');
INSERT INTO FATTURA (ID_FATTURA, ID_PAGAMENTO, DATA) VALUES ('03', '3', '2021-02-07');
INSERT INTO FATTURA (ID_FATTURA, ID_PAGAMENTO, DATA) VALUES ('04', '4', '2020-06-11');








