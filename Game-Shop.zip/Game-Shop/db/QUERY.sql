USE GAMESHOP;
/*OPERAZIONE1********************************
CREAZIONE NUOVO ACCOUNT**************/

/*INSERT INTO UTENTE (id_utente,email, codice_catalogo, password)	VALUES ( '7','ale7890@libero.it','1',md5('abcdefghijkl'));
/*L'utente sarà obbligato ad inserire i suoi dati Anagrafici*/
/*INSERT INTO DATI_ANAGRAFICI (id_utente,ID_CITTà, NOME, COGNOME, INDIRIZZO,telefono1,telefono2) values ('7', '2', 'enzo', 'fischetti','via pablo 10','082365987',null);
/* A seconda se l'utente vorrà inserire una rubrica indirizzi:**/
/*INSERT INTO rubrica_indirizzi (id_indirizzo, id_utente,id_città, nome, cognome, indirizzo)  values ('9','7','2','ENZO','FISCHETTI','VIA PABLO 47');
/*****OPERAZIONE2*/
/* AGGIUNTA DI UN ARTICOLO AD UN ORDINE RELATIVO AD UN UTENTE*/
/*INSERT INTO COMPONGONO (CODICE_ARTICOLI, NUMERO_ORDINE, quantità) VALUES ('01','3','1');
update ordine set importo_totale=importo_totale+40/*(+ sarebbe importo articolo da aggiungere al totale)*//* , numero_articoli=numero_articoli+1 where numero_ordine=3;/*

/*****OPERAZIONE 3***** INSERIMENTO DI UN NUOVO ORDINE RELATIVO AD 1 UTENTE GIà REGISTRATO*/
/*INSERT INTO ORDINE (NUMERO_ORDINE, id_utente, IMPORTO_TOTALE, NUMERO_ARTICOLI) VALUES ('4', '1', '70.00','1');

/*******L'ORDINE CONTERRà PER AL MINIMO UN ARTICOLO*/
/*INSERT INTO COMPONGONO (CODICE_ARTICOLI, NUMERO_ORDINE, quantità) VALUES ('02','4','1');

/*OPERAZIONE 4 ****ELENCARE TUTTI GLI ORDINI CON LE RELATIVE INFORMAZIONI
SELECT * FROM ORDINE;
/*
OPERAZIONE 5 ****STAMPARE TUTTE LE INFORMAZIONI RELATIVE AD UN UTENTE*/
/*select email,nome,cognome,indirizzo,Nome_città,nome_cap,nome_provincia from dati_anagrafici as d, città as c, provincia,cap ,utente where utente.email= 'MarioRossi@libero.it' and d.id_utente=utente.id_utente and c.id_città=d.id_città and cap.id_città=c.id_città 
and cap.id_provincia=provincia.id_provincia;*/

/*OPERAZIONE 6 INSERISCI SPEDIZIONE STANDARD PER UN ORDINE*/
/*INSERT INTO STANDARD (id_spedizione, numero_ordine, data_spedizione, costo) VALUES ('2','4', '2021-02-07', '10.00');*/

/*OPERAZIONE 7 ***INSERISCI PAGAMENTO CON CARTA PER UN ORDINE*/

/*insert INTO PAGAMENTO (id_pagamento, numero_ordine, importo_pagamento) values ('4','4','80');
INSERT INTO CARTA (numero_di_carta, id_pagamento, dati_intestatario) VALUES  ('4566895674104598','4','MARIO ROSSI');
/*COMPORTERà L'INSERIMENTO DI UNA FATTURA */
/*INSERT INTO  FATTURA (ID_FATTURA, ID_PAGAMENTO, DATA) VALUES ('4','4','2021-02-08');*/

/* OPERAZIONE 8 *******ELENCARE I FORNITORI DI TUTTI GLI ARTICOLI NEL CATALOGO*/
/*SELECT  CODICE_ARTICOLI, NOME, INDIRIZZO, F.PARTITA_IVA FROM SONO_FORNITI_DA, FORNITORE AS F WHERE F.PARTITA_IVA=SONO_FORNITI_DA.PARTITA_IVA order by CODICE_ARTICOLI ASC;*/

/*OPERAZIONE 9 ELENCARE IL NOME,LA DESCRIZIONE E IL CODICE DEGLI ARTICOLI NON IN OFFERTA  ACQUISTATI NEL 2020 CON CONSEGNA DI TIPO STANDARD E PAGATI O I CONTANTI O CON CARTA.

SELECT  a.NOMI,a.DESCRIZIONE 
from articoli as a , compongono as c ,ordine as  o, pagamento as p ,fattura as f 

where f.data between '2020-01-01' and '2020-12-31'and  a.tipologia_articoli='Articolo Non in offerta' and c.numero_ordine=o.numero_ordine AND p.numero_ordine=o.numero_ordine 
and a.codice_articoli=c.codice_articoli and (exists 
(select * from carta as c where c.id_pagamento=p.id_pagamento and c.id_pagamento=f.id_pagamento) or 
exists 
(select * from contanti as cont where cont.id_pagamento=p.id_pagamento and cont.id_pagamento=f.id_pagamento));

*/
/*OPERAZIONE 10 SELEZIONA IL NOME, IL COGNOME L'EMAIL, IL NUMERO DI TELEFONO, quantità articoli DEGLI UTENTI CHE HANNO ACQUISTATO PIù DI UN ARTICOLO*/
/*SELECT distinct d.nome,d.cognome, d.telefono1,d.telefono2,u.email, o.numero_articoli from dati_anagrafici as d, utente as u,ordine as o ,pagamento as p where  d.id_utente=u.id_utente and o.id_utente=u.id_utente and o.numero_articoli>1 and p.numero_ordine=o.numero_ordine;
*/
/*OPERAZIONE 11 SELEZIONA 

