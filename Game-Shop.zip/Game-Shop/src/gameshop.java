import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/*import java.sql.ResultSetMetaData;*/
import java.sql.SQLException;
import java.sql.Statement;


public class gameshop {

	public gameshop() {
	}

	private Connection getConnection() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/gameshop?zeroDateTimeBehavior=CONVERT_TO_NULL";

		Connection connection = DriverManager.getConnection(url, "gmshopuser", "gmshopuser");
		System.out.println("Connessione OK \n");

		return connection;
	}

	private void releaseConnection(Connection connection) throws SQLException {
		if (connection != null) {
			connection.close();
			connection = null;
		}
	}

	public void testConnection() {
		try {
			Connection connection = getConnection();
			releaseConnection(connection);
		} catch (Exception e) {
			System.err.println("Connessione Fallita \n");
			System.err.println(e);
		}
	}

	public void release() {
		try {
			DBConnectionPool.releaseAllConnection();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		}
	}
	////////////////////////////////////////////////////////////MD5 SU PASSWORD//////////////////////////////////////////////////////////////////////////////////////////////////////
	public static String getMD5Hash(String s) throws NoSuchAlgorithmException {

		String result = s;
		if (s != null) {
		    MessageDigest md = MessageDigest.getInstance("MD5"); // or "SHA-1"
		    md.update(s.getBytes());
		    BigInteger hash = new BigInteger(1, md.digest());
		    result = hash.toString(16);
		    while (result.length() < 32) { // 40 for SHA-1
		        result = "0" + result;
		    }
		}
		return result; }
	

	
	
	

	
///////////////////////////////OPERAZIONE____1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////CREAZIONE NUOVO ACCOUNT/////////////////////////////////////////////////////////////////////////////////////////////
	public void parametricInsert(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		
		ResultSet rs = null;
	
		try {
			con = DBConnectionPool.getConnection();

			String sql = "INSERT INTO utente(email,password) VALUES (?,?)";
			ps = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			
			
			
			ps.setString(1, valore.getEmail());
		/*	ps.setInt(2, valore.getCodice_Catalogo());*/
			
			ps.setString(2, valore.getPassword());
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
		
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
		
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try (ResultSet generatedKeys = ps.getGeneratedKeys())
				
				{
		            if (generatedKeys.next()) {
		                valore.setId(generatedKeys.getInt(1));
		            }
		            else {
		                throw new SQLException("Creating user failed, no ID obtained.");
		            }
		        
			
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}

	
	public void dati_anagrafici(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO DATI_ANAGRAFICI (id_utente,id_citt�, NOME, COGNOME, INDIRIZZO,telefono1,telefono2) SELECT max(id_utente),?,?,?,?,?,? from utente";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getId_città());
			ps.setString(2,valore.getNome());
			ps.setString(3, valore.getCognome());
			ps.setString(4,valore.getIndirizzo());
			ps.setString(5,valore.get_telefono1());
			ps.setString(6,valore.get_telefono2());
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	
	public void rubrica_indirizzi(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO rubrica_indirizzi ( id_utente,id_citt�, nome, cognome, indirizzo)  select max(id_utente),?,?,?,? from utente";
			ps = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			
			ps.setInt(1, valore.getId_città());
			ps.setString(2,valore.getNome_indirizzo());
			ps.setString(3, valore.getCognome());
			ps.setString(4,valore.getIndirizzo());
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try (ResultSet generatedKeys = ps.getGeneratedKeys())
			
			{
	            if (generatedKeys.next()) {
	                valore.setId(generatedKeys.getInt(1));
	            }
	            else {
	                throw new SQLException("Creating user failed, no ID obtained.");
	            }
				
				
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
//////////////////////////////////////////////////////////////FINE OPERAZIONE1/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
/////////////////////////////////////OPERAZIONE_2//////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////AGGIUNTA DI UN ARTICOLO RELATIVO AD 1 ORDINE DI 1 UTENTE////////////////////////////////////////////////////////////
	
	public void COMPONGONO(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO COMPONGONO (CODICE_ARTICOLI, NUMERO_ORDINE, quantit�) VALUES (?,?,?);";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getCodice_articoli());
			ps.setInt(2,valore.getNumero_ordine());
			ps.setInt(3, valore.getQuantità());
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	public void update(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "update ordine set importo_totale=(select sum(prezzo) from articoli as a,compongono as c where a.codice_articoli= c.codice_articoli and numero_ordine=?) , numero_articoli=(select sum(quantit�) from compongono as c where numero_ordine=?) where numero_ordine=?;";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getNumero_ordine());
			ps.setInt(2,valore.getNumero_ordine());
			ps.setInt(3, valore.getNumero_ordine());
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	
	//////////////////////////////////////////////////////////////////FINE OPERAZIONE2////////////////////////////////////////////////////////////////////////////////////
	
	
	
	/////////////////////////INIZIO OPERAZIONE 3//////////////////////////////////////////////////////////////////////////////////////
	
	
	
	public void inserisci_ordine(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO ORDINE (id_utente, IMPORTO_TOTALE, NUMERO_ARTICOLI) VALUES ( ?, ?, ?)";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getId());
			
			
			
			ps.setInt(2,valore.getImporto_totale());
			ps.setInt(3,valore.getNumero_articoli());
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	
	
	public void compone_ordine(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO COMPONGONO (CODICE_ARTICOLI, NUMERO_ORDINE, quantità) select ?, max(o.numero_ordine),? from articoli, ordine as o, compongono;";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getCodice_articoli());
			
			
			
			ps.setInt(2,valore.getQuantità());
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	/////////////////////////////////////////FINE OPERAZIONE 3//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
/////////////////////////////////////////////////////////////////////////OPERAZIONE__4///////////////////////////////////////////////////////////////////////////////////////////////	
public void retrieve() {
Connection con = null;
Statement st = null;
ResultSet rs = null;
try {
con = DBConnectionPool.getConnection();
st = con.createStatement();

String sql = "SELECT * FROM ORDINE";
System.out.println("QUERY: " + sql);

rs = st.executeQuery(sql);


while (rs.next()) {
String numero_ordine = rs.getString("numero_ordine");
String id_utente=rs.getString("id_utente");
double importo_totale=rs.getDouble("importo_totale");
int numero_articoli=rs.getInt("numero_articoli");

System.out.print("numero_ordine: " +numero_ordine);
System.out.print(", id_utente: " + id_utente);
System.out.print(", importo_totale: " + importo_totale);
System.out.println(", numero_articoli: " + numero_articoli);
}
} catch (SQLException s) {
System.err.println(s.getMessage());
Utility.printSQLException(s);
} finally {
try {
if (rs != null)
rs.close();
if (st != null)
st.close();
DBConnectionPool.releaseConnection(con);
} catch (SQLException s) {
System.err.println(s.getMessage());
Utility.printSQLException(s);
}
}
}
////////////////////////////////////////////////////////////////////////////////////////FINE OPERAZIONE 4///////////////////////////////////////////////////////////////////////////////////////////	





//////////////////////////////////////////////////////////INIZIO OPERAZIONE 5//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public void info_utente(String param_email) {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	try {
		con = DBConnectionPool.getConnection();
		

		String sql = "select email,nome,cognome,indirizzo,Nome_citt�,nome_cap,nome_provincia from dati_anagrafici as d, citt� as c, provincia,cap ,utente where utente.email= ? and d.id_utente=utente.id_utente and c.id_citt�=d.id_citt� and cap.id_citt�=c.id_citt� \n"
				+ "and cap.id_provincia=provincia.id_provincia ";
		ps = con.prepareStatement(sql);
		ps.setString(1, param_email);
		
		
		System.out.println("QUERY: " + ps);
		
		rs = ps.executeQuery();

		
		while (rs.next()) {
			String email=rs.getString("email");
			String nome =rs.getString("nome");
			String cognome =rs.getString("cognome");
			String indirizzo =rs.getString("indirizzo");
			String nome_città =rs.getString("nome_città");
			Integer nome_cap=rs.getInt("nome_cap");
			
			
			System.out.print("email: " +email);
	         System.out.print(", nome: " + nome);
	         System.out.print(", cognome: " +cognome);
	         System.out.print(", indirizzo: " + indirizzo);
	         System.out.print(", nome_città: " + nome_città);
	         System.out.println(", nome_cap: " + nome_cap);
	         
		}
	} catch (SQLException s) {
		System.err.println(s.getMessage());
		Utility.printSQLException(s);
	} finally {
		try {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			DBConnectionPool.releaseConnection(con);
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		}
	}
}
//////////////////////////////////////////////////////////////////////////////////FINE OPERAZIONE 5/////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////OPERAZIONE 6////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////INSERISCI SPEDIZIONE STANDARD PER UN ORDINE///////////////////////////////////////////////////////////////////////////////////
	
	public void inserisci_spedizione(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO STANDARD (numero_ordine, data_spedizione, costo) VALUES ( ?,?,?);";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getNumero_ordine());
			
			if (valore.getData_spedizione() != null) {
				ps.setDate(2, Utility.toSqlDate(valore.getData_spedizione()));
			}
			ps.setDouble(3, valore.getCosto());
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	/////////////////////////FINE OPERAZIONE 6////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/////////////////////////////////////////////////////INIZIO OPERAZIONE 7///////////////////////////////////////////////////////////////////
	///////////////////////////////INSERISCI PAGAMENTO CON CARTA PER UN ORDINE//////////////////////////////////////////
	
	
	
	public void inserisci_pagamento(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "insert INTO PAGAMENTO ( numero_ordine, importo_pagamento) values (?,?);";
			ps=con.prepareStatement(sql);
			
			ps.setInt(1, valore.getNumero_ordine());
			
			
			ps.setDouble(2, valore.getImporto_pagamento());
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	
	public void inserisci_cartapagamento(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO CARTA (numero_di_carta, id_pagamento, dati_intestatario) select ?, max(p.id_pagamento),? from carta, pagamento as p;";
			ps=con.prepareStatement(sql);
			
			ps.setString(1, valore.getNumero_dicarta());
			ps.setString(2, valore.getdati_intestatario());
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	public void inserisci_fattura(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO  FATTURA ( ID_PAGAMENTO, DATA) select  max(p.id_pagamento),? from  pagamento as p,fattura ;";
			ps=con.prepareStatement(sql);
			
			/*ps.setInt(1, valore.getId_pagamento());*/
			
			if (valore.getData_fatturazione() != null) {
				ps.setDate(1, Utility.toSqlDate(valore.getData_fatturazione()));
			}
			
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
//////////////////////////////////////////FINE OPERAZIONE 7///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
//////////////////////////////////////////////////////////////////////INIZIO OPERAZIONE 8//////////////////////////////////////////////////////////////////////////////
	
	
	
	public void fornitori() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();
			st = con.createStatement();

			String sql = "SELECT  CODICE_ARTICOLI, NOME, INDIRIZZO, F.PARTITA_IVA,F.ID_FORNITORE FROM SONO_FORNITI_DA, FORNITORE AS F WHERE F.id_fornitore=SONO_FORNITI_DA.id_fornitore order by CODICE_ARTICOLI ASC;";
			System.out.println("QUERY: " + sql);

			rs = st.executeQuery(sql);

			fornitore.printTitle_fornitori();
			while (rs.next()) {
				
				fornitore fornitore= new fornitore();
			fornitore.setCodice_articoli(rs.getInt("codice_articoli"));
				fornitore.setNome_fornitore(rs.getString("NOME"));
				fornitore.setIndirizzo(rs.getString("INDIRIZZO"));
				fornitore.setPartita_iva(rs.getString("PARTITA_IVA"));
				fornitore.setId_fornitore(rs.getInt("ID_FORNITORE"));
			
				fornitore.print_fornitori();
			}
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	
	///////////////////////////////////FINE OPERAZIONE 8////////////////////////////////////////////////////////////////////////////
	
	
	
	
	///////////////////////////////////INIZIO OPERAZIONE 9/////////////////////////////////////////////////////////////////////////////////////////
	//ELENCARE IL NOME,LA DESCRIZIONE E IL CODICE DEGLI ARTICOLI NON IN OFFERTA  ACQUISTATI NEL 2020 CON CONSEGNA DI TIPO STANDARD E PAGATI O I CONTANTI O CON CARTA./////////
	
	
	public void OPERAZIONE_9() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();
			st = con.createStatement();

			String sql = "SELECT  a.NOMI,a.DESCRIZIONE \n"
					+ "from articoli as a , compongono as c ,ordine as  o, pagamento as p ,fattura as f \n"
					+ "\n"
					+ "where f.data between '2020-01-01' and '2020-12-31'and  a.tipologia_articoli='Articolo Non in offerta' and c.numero_ordine=o.numero_ordine AND p.numero_ordine=o.numero_ordine \n"
					+ "and a.codice_articoli=c.codice_articoli and (exists \n"
					+ "(select * from carta as c where c.id_pagamento=p.id_pagamento and c.id_pagamento=f.id_pagamento) or \n"
					+ "exists \n"
					+ "(select * from contanti as cont where cont.id_pagamento=p.id_pagamento and cont.id_pagamento=f.id_pagamento));";
			System.out.println("QUERY: " + sql);

			rs = st.executeQuery(sql);

			utente.printTitle_op9();
			while (rs.next()) {
				utente utente = new utente();
			utente.setNomi_articoli(rs.getString("nomi"));
			
				utente.setDescrizione_articoli(rs.getString("descrizione"));
				
				
				utente.print_op9();
			}
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	
	//////////////////////////////////////////////////////////FINE OPERAZIONE 9////////////////////////////////////////////////////////////////////
	
	
///////////////////////////////////////////////////////////INIZIO OPERAZIONE 10//////////////////////////////////////////////////////////////////////////////////
/////////////SELEZIONA IL NOME, IL COGNOME L'EMAIL, IL NUMERO DI TELEFONO, quantit� articoli DEGLI UTENTI CHE HANNO ACQUISTATO PI� DI UN ARTICOLO///////////////
	
	
	
	public void OPERAZIONE_10() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();
			st = con.createStatement();

			String sql = "SELECT distinct d.nome,d.cognome, d.telefono1,d.telefono2,u.email, o.numero_articoli from dati_anagrafici as d, utente as u,ordine as o ,pagamento as p where  d.id_utente=u.id_utente and o.id_utente=u.id_utente and o.numero_articoli>1 and p.numero_ordine=o.numero_ordine;\n";
			System.out.println("QUERY: " + sql);

			rs = st.executeQuery(sql);

			utente.printTitle_op10();
			while (rs.next()) {
				utente utente = new utente();
			utente.setNome(rs.getString("nome"));
			utente.setCognome(rs.getString("cognome"));
			utente.setTelefono1(rs.getString("telefono1"));
			utente.setTelefono2(rs.getString("telefono2"));
				utente.setEmail(rs.getString("email"));
				utente.setNumero_articoli(rs.getInt("numero_articoli"));
				
				
				utente.print_op10();
			}
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	
	
////////////////////////////////////FINE OPERAZIONE 10///////////////////////////////////////////////////////////////////////////////////////////////

	
	
	
	
///////////////////////////////////////////INIZIO OPERAZIONE 11//////////////////////////////////////////////////
////////SELEZIONA il nome,il cognome,l'email e il numero dell' ordine corrispondente  degli utenti della provincia di salerno che hanno comprato almeno 2 articoli,////
////////////////////////di cui uno in offerta, e hanno scelto la consegna standard e non hanno pagato con carta o con bonifico///////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public void OPERAZIONE_11() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();
			st = con.createStatement();

			String sql = "select distinct  d.nome,d.cognome,u.email ,o.numero_ordine,sum(o.numero_articoli) as articoli\n"
					+ "from utente as u, dati_anagrafici as d ,provincia as p ,cap,città,ordine as o ,veloce as v,compongono as c,articoli as a\n"
					+ " where  a.tipologia_articoli='Pacchetto combo in offerta' and a.codice_articoli=c.codice_articoli and c.quantit�='1'and c.numero_ordine=o.numero_ordine and p.nome_provincia='Salerno'  and cap.id_provincia=p.id_provincia and cap.id_citt�=citt�.id_citt� and v.numero_ordine=o.numero_ordine\n"
					+ " and d.id_citt�=citt�.id_citt� and u.id_utente=d.id_utente and u.id_utente=o.id_utente \n"
					+ " and not exists(select * from carta ,pagamento as pag,bonifico where carta.id_pagamento=pag.id_pagamento and bonifico.id_pagamento=pag.id_pagamento and pag.numero_ordine=o.numero_ordine)\n"
					+ "  group by u.id_utente \n"
					+ "  having articoli>1;\n"
					+ "";
				
			
			
			
			System.out.println("QUERY: " + sql);

			rs = st.executeQuery(sql);

			utente.printTitle_op11();
			while (rs.next()) {
				utente utente = new utente();
			utente.setNome(rs.getString("nome"));
			utente.setCognome(rs.getString("cognome"));
			utente.setEmail(rs.getString("email"));
			utente.setNumero_ordine(rs.getInt("numero_ordine"));
			
				
				utente.setArticoli(rs.getInt("articoli"));
				
				
				utente.print_op11();
			}
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	
	
	/////////////////////////////////////////////////FINE OPERAZIONE 11////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////INIZIO OPERAZIONE 12////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////Inserimento articolo nel catalogo///////////////////////////////////////////////////////////////
	
	public void inserisci_articolo(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO Articoli (descrizione, prezzo, nomi, tipologia_articoli) VALUES (?,?,?,?);";
			ps=con.prepareStatement(sql);
			
			/*ps.setInt(1, valore.getCodice_Catalogo());*/
			
			
			
			ps.setString(1,valore.getDescrizione_articoli());
			ps.setDouble(2,valore.getCosto());
			ps.setString(3,valore.getNomi_articoli());
			ps.setString(4,valore.getTipologia_articoli());
			
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	public void sono_forniti_da(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO SONO_FORNITI_DA (CODICE_ARTICOLI, id_fornitore) select max(A.codice_articoli) , 1 FROM ARTICOLI AS A;";
			ps=con.prepareStatement(sql);
			
		
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	///////////////////////////////////////////////////////////////////////////fine OPERAZIONE12/////////////////////////////////
	
	/////////////////////INIZIO OPERAZIONE 13////////////////////////////////////////////////////////////////
	/////////////////////Inserimento di un nuovo fornitore///////////////////////////////////
	
	
	
	public void inserisci_FORNITORE(fornitore valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO FORNITORE (NOME, INDIRIZZO, PARTITA_IVA) VALUES ( ?,?,?);";
			ps=con.prepareStatement(sql);
			
			
			ps.setString(1, valore.getNome_fornitore());
			
			
			ps.setString(2,valore.getIndirizzo());
		
			ps.setString(3,valore.getPartita_Iva());
			
			
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	public void inserisci_articoloFornitore(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO Articoli (descrizione, prezzo, nomi, tipologia_articoli) VALUES (?,?,?,?);";
			ps=con.prepareStatement(sql);
			
			/*ps.setInt(1, valore.getCodice_Catalogo());*/
			
			
			
			ps.setString(1,valore.getDescrizione_articoli());
			ps.setDouble(2,valore.getCosto());
			ps.setString(3,valore.getNomi_articoli());
			ps.setString(4,valore.getTipologia_articoli());
			
			
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	public void sono_forniti_da_fornitore(utente valore)throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = DBConnectionPool.getConnection();

		
		
			String sql= "INSERT INTO SONO_FORNITI_DA (CODICE_ARTICOLI, ID_FORNITORE) VALUES"
					+ "((select max(codice_articoli)  from articoli as a),"
					+ "(SELECT max(id_fornitore) FROM fornitore ));";
			ps=con.prepareStatement(sql);
			
		
			
			System.out.println("QUERY: " + ps);
			
			int result = ps.executeUpdate();
			
			
			
			if (result > 0) {
				System.out.println("Inserimento effettuato");
			} else {
				System.out.println("Impossibile inserire il/i record");
			}
			
			
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try 
				
				{
		       if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
		
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//////////////////////////////////////////INIZIO OPERAZIONE 14//////////////////////////////////////////////////////////////////
	
	public void OPERAZIONE_14() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();
			st = con.createStatement();

			String sql = "select u.email as email_utente, nome as nome_impostato_per_indirizzo_destinatario,cognome as cognome_per_indirizzo_destinatario, indirizzo as indirizzo_impostato_nella_rubrica from utente as u,rubrica_indirizzi where u.id_utente=rubrica_indirizzi.id_utente;";
			System.out.println("QUERY: " + sql);

			rs = st.executeQuery(sql);

			utente.printTitle_op14();
			while (rs.next()) {
				utente utente = new utente();
			utente.setEmail(rs.getString("email_utente"));
			
				utente.setNome(rs.getString("nome_impostato_per_indirizzo_destinatario"));
				utente.setCognome(rs.getString("cognome_per_indirizzo_destinatario"));
				utente.setIndirizzo(rs.getString("indirizzo_impostato_nella_rubrica"));
				
				
				utente.print_op14();
			}
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	////////////////////////////////////////////////OPERAZIONE 15//////////////////////////////////////////////////////////////////////////////////
	
	public void delete(String NUMERO_ORDINE) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();

			st = con.createStatement();

			String sql = "DELETE FROM ORDINE WHERE numero_ordine ='" + NUMERO_ORDINE + "'";
			System.out.println("QUERY: " + sql);

			int result = st.executeUpdate(sql);
			if (result > 0) {
				System.out.println("Cancellazione effettuata");
			} else {
				System.out.println("Impossibile cancellare il/i record");
			}
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	////////////////////////////////////////////////////fine operazione 15//////////////////////////////////
	
	/////////////////////INIZIO OPERAZIONE 16//////////////////////////////////////////////////////
	
	public void delete_WITH_EMAIL(String EMAIL) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();

			st = con.createStatement();

			String sql = "DELETE FROM ORDINE WHERE EXISTS(SELECT * FROM UTENTE AS U WHERE U.EMAIL ='" + EMAIL + "' and ordine.id_utente=u.id_utente);";
			System.out.println("QUERY: " + sql);

			int result = st.executeUpdate(sql);
			if (result > 0) {
				System.out.println("Cancellazione effettuata");
			} else {
				System.out.println("Impossibile cancellare il/i record");
			}
			con.commit();
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	/////////////////////////////////////////FINE OPERAZIONE 16//////////////////////////////////////////////////////////////////////////
	///////////////////////////INIZIO OPERAZIONE 17//////////////////////////////
	
	public void OPERAZIONE_17() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = DBConnectionPool.getConnection();
			st = con.createStatement();

			String sql = "select nome_citt� from citt�  where not exists(select * from dati_anagrafici as d where d.id_citt�=citt�.id_citt�);";
			System.out.println("QUERY: " + sql);

			rs = st.executeQuery(sql);

			utente.printTitle_op17();
			while (rs.next()) {
				utente utente = new utente();
			utente.setNome(rs.getString("nome_citt�"));
			
			
				
				utente.print_op17();
			}
		} catch (SQLException s) {
			System.err.println(s.getMessage());
			Utility.printSQLException(s);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (st != null)
					st.close();
				DBConnectionPool.releaseConnection(con);
			} catch (SQLException s) {
				System.err.println(s.getMessage());
				Utility.printSQLException(s);
			}
		}
	}
	
	
	
///////////////////////////////////////////////////////////////////////SWITCH/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	private void ui() throws IOException, NoSuchAlgorithmException, SQLException {
		int i = 0;
		String scelta;
		Scanner myObj = new Scanner(System.in);

		InputStreamReader keyIS = new InputStreamReader(System.in);
		BufferedReader keyBR = new BufferedReader(keyIS);

		while (i != 1000) {// inizio while
			System.out.println("\nOperazioni Game-shop:");
			System.out.println("*******************************************************************************************************************************************************************************************");
			System.out.println("1, inserimento Dati di un Nuovo Utente\n");
			
			System.out.println("2, AGGIUNTA DI UN ARTICOLO AD UN ORDINE RELATIVO AD UN UTENTE\n");
			System.out.println("3, INSERIMENTO DI UN NUOVO ORDINE RELATIVO AD 1 UTENTE GI� REGISTRATO\n");
			System.out.println("4, Seleziona tutti gli ordini con le informazioni relative ad ognuno\n");
			System.out.println("5, SELEZIONA TUTTE LE INFORMAZIONI SU 1 UTENTE\n");
			System.out.println("6, INSERISCI SPEDIZIONE STANDARD PER UN ORDINE\n");
			System.out.println("7, INSERISCI PAGAMENTO CON CARTA PER UN ORDINE\n");
			System.out.println("8,ELENCA I FORNITORI DI TUTTI GLI ARTICOLI NEL CATALOGO\n ");
			System.out.println("9, ELENCARE IL NOME,LA DESCRIZIONE E IL CODICE DEGLI ARTICOLI NON IN OFFERTA  ACQUISTATI NEL 2020 CON CONSEGNA DI TIPO STANDARD E PAGATI O I CONTANTI O CON CARTA\n");
			System.out.println("10, SELEZIONA IL NOME, IL COGNOME L'EMAIL, IL NUMERO DI TELEFONO, quantit� articoli DEGLI UTENTI CHE HANNO ACQUISTATO PI� DI UN ARTICOLO\n");
			System.out.println("11, SELEZIONA il nome,il cognome,l'email e il numero dell' ordine corrispondente  degli utenti della provincia di salerno che hanno comprato almeno 2 articoli,di cui uno in offerta,\n e hanno scelto la consegna standard e non hanno pagato con carta o con bonifico\n");
			System.out.println("12, Inserimento articolo nel catalogo che ha come fornitore 'Videogiochi & C\n");
			System.out.println("13, Inserimento di un nuovo fornitore \n");
			System.out.println("14, Seleziona tutti gli indirizzi inseriti nella rubrica indirizzi con l�informazione su quale email utente � assoociata\n");
			System.out.println("15, Cancella Ordine con scelta numero ordine da cancellare\n");
			System.out.println("16, Cancella Tutti gli ordini relativi ad 1 utente\n");
			System.out.println("17, Elenca nome delle citt� che non hanno ancora utenti registrati\n");
			
			System.out.println("1000, per uscire");
			System.out.println("*********************************************************************************************************************************************************************************************");

			System.out.print("Inserisci scelta: ");
			scelta = keyBR.readLine();

			try {// inizio try-catch
				i = Integer.parseInt(scelta);
				
			} catch (NumberFormatException e) {
				i = 999;
			} // fine try-catch

			System.out.println();
			switch (i) {
			case 1: {
				System.out.println("Inserimento Utente con dati");
				
				String param1 = Utility.readLine("Inserisci email", "varchar(250)", true);
			/*	String param2 = Utility.readLine("Inserisci codice_catalogo", "int", true);*/
				String param3 = Utility.readLine("Inserisci password", "password", true);
				String param4=getMD5Hash(param3);
				utente utente = new utente();
				
				utente.setEmail(param1);
				utente.setPassword(param4);
		/*	if (param2 != null ) {
					utente.setCodice_catalogo(Integer.valueOf(param2));
					
				}*/
				
			String param5 = Utility.readLine("Inserisci id_citt� : (1=Calitri,2=AVELLINO,3=BISACCIA,4=FISCIANO,5=ANGRI,6=POMPEI,7=ROMA)", "int", true);
			String param6 = Utility.readLine("Inserisci Nome", "varchar(50)", true);
			String param7 = Utility.readLine("Inserisci cognome", "varchar(25)", true);
			String param8 = Utility.readLine("Inserisci Indirizzo", "varchar(250)", true);
			String param9 = Utility.readLine("Inserisci Telefono1", "varchar(9)", true);
			String param10 = Utility.readLine("Inserisci Telefono2", "varchar(10)", true);
			
			utente.setId_città(Integer.valueOf(param5));
			utente.setNome(param6);
			utente.setCognome(param7);
			utente.setIndirizzo(param8);
			utente.setTelefono1(param9);
			utente.setTelefono2(param10);
			this.parametricInsert(utente);
			this.dati_anagrafici(utente);
				System.out.print("Schiaccia 2 se vuoi inserire dati nella rubrica indirizzi:");
				int f=myObj.nextInt();
				
				
			if (f==2) {
					System.out.println("Inserimento Nella Rubrica Indirizzi:");
					
					String param11 = Utility.readLine("Inserisci id_città : (1=Calitri,2=AVELLINO,3=BISACCIA,4=FISCIANO,5=ANGRI,6=POMPEI,7=ROMA)", "int", false);
					String param12 = Utility.readLine("Inserisci Nome", "varchar(25)", true);
					String param13 = Utility.readLine("Inserisci cognome", "varchar(25)", true);
					String param14 = Utility.readLine("Inserisci Indirizzo", "varchar(25)", true);
					utente.setId_città(Integer.valueOf(param11));
					utente.setNome_indirizzo(param12);
					utente.setCognome(param13);
					utente.setIndirizzo(param14);
					rubrica_indirizzi(utente);
				}
				else {
					System.out.println("Uscita");
					break;
				}
					myObj.close();	
				break;
				
			}
				
			
	
				
			case 2: {
				System.out.println("Aggiunta articolo ad 1 ordine relativo ad 1 utente");
				
				
				String param1 = Utility.readLine("Inserisci codice articoli", "int)", true);
				String param2 = Utility.readLine("Inserisci numero_ordine", "int", true);
				String param3 = Utility.readLine("Inserisci quantit�", "int", true);
				utente utente = new utente();
				
				utente.setCodice_articoli(Integer.valueOf(param1));
				utente.setNumero_ordine(Integer.valueOf(param2));
				utente.setQuantità(Integer.valueOf(param3));
				
				
				
				String param4 = Utility.readLine("Inserisci numero_ordine", "int", true);
				
				utente.setNumero_ordine(Integer.valueOf(param4));
				this.COMPONGONO(utente);
				this.update(utente);
				
				
				
				
				
				break;
			}
			case 3: {
				System.out.println("INSERIMENTO DI UN NUOVO ORDINE RELATIVO AD 1 UTENTE GI� REGISTRATO");
				String param1 = Utility.readLine("Inserisci id_utente", "int)", true);
				String param2 = Utility.readLine("Inserisci importo_totale", "int", true);
				String param3 = Utility.readLine("Inserisci numero_articoli", "int", true);
				utente utente=new utente();
				
				utente.setId(Integer.valueOf(param1));
				utente.setImporto_totale(Integer.valueOf(param2));
				utente.setNumero_articoli(Integer.valueOf(param3));
				
				String param4 = Utility.readLine("Inserisci codice_articoli", "int", true);
				String param5 = Utility.readLine("Inserisci quantit�", "int", true);
				
				utente.setCodice_articoli(Integer.valueOf(param4));
				utente.setQuantità(Integer.valueOf(param5));
				this.inserisci_ordine(utente);
				this.compone_ordine(utente);
				break;
			}
			
			case 4: {
				System.out.println("Visualizza tutti gli ordini");
				retrieve();
				break;
			}
			case 5: {
				System.out.println("Stampare tutte le informazioni su un utente");
				String param1 = Utility.readLine("Scegliere utente da trovare","varchar(25)", true);
				this.info_utente(param1);
				break;
			}
			case 6: {
				System.out.println("INSERISCI SPEDIZIONE STANDARD PER UN ORDINE");
				String param1 = Utility.readLine("Inserisci Numero ordine a cui inserire spedizione standard", "int", true);
				String param2 = Utility.readLine("Inserisci data della spedizione", "yyyy-mm-dd", false);
				String param3 = Utility.readLine("Inserisci Costo della spedizione", "float", true);
				utente utente=new utente();
				
				
				utente.setNumero_ordine(Integer.valueOf(param1));
				utente.setDataSpedizione(Utility.formatStringToDate(param2));
				utente.setCosto(Double.valueOf(param3));
				
				this.inserisci_spedizione(utente);
				
			
				break;
			}
			case 7: {
				System.out.println("INSERISCI PAGAMENTO CON CARTA PER UN ORDINE");
				String param1 = Utility.readLine("Inserisci Numero ordine", "int", true);
				String param2 = Utility.readLine("Inserisci Importo pagamento", "double", true);
				String param3 = Utility.readLine("Inserisci Numero di carta", "varchar", true);
				String param4 = Utility.readLine("Inserisci Dati intestatario", "varchar", true);
				String param5 = Utility.readLine("Inserisci data fatturazione", "yyyy-mm-dd", false);
				utente utente=new utente();
				
				utente.setNumero_ordine(Integer.valueOf(param1));
				utente.setImporto_pagamento(Double.valueOf(param2));
				utente.setNumero_dicarta(param3);
				utente.setdati_intestatario(param4);
				utente.setData_fatturazione(Utility.formatStringToDate(param5));
				
				
				this.inserisci_pagamento(utente);
				this.inserisci_cartapagamento(utente);
				this.inserisci_fattura(utente);
				break;
			}
			case 8: {
				System.out.println("ELENCO I FORNITORI DI TUTTI GLI ARTICOLI NEL CATALOGO");
				this.fornitori();
				break;
			}
			
			case 9: {
				System.out.println("ELENCARE IL NOME,LA DESCRIZIONE E IL CODICE DEGLI ARTICOLI NON IN OFFERTA  ACQUISTATI NEL 2020 CON CONSEGNA DI TIPO STANDARD E PAGATI O I CONTANTI O CON CARTA");
				this.OPERAZIONE_9();
				break;
			}
			case 10: {
				System.out.println("SELEZIONA IL NOME, IL COGNOME L'EMAIL, IL NUMERO DI TELEFONO, quantit� articoli DEGLI UTENTI CHE HANNO ACQUISTATO PI� DI UN ARTICOLO");
				
				this.OPERAZIONE_10();
				break;
			}
	
			case 11:{
				
				System.out.println("SELEZIONA il nome,il cognome,l'email e il numero dell' ordine corrispondente  degli utenti della provincia di salerno che hanno comprato almeno 2 articoli,"
						+ "di cui uno in offerta,"
						+ " e hanno scelto la consegna standard e non hanno pagato con carta o con bonifico");
				
				
				this.OPERAZIONE_11();
				break;
				
			}
			case 12:{
				System.out.println("Inserimento articolo nel catalogo");
			/*	String param1 = Utility.readLine("Inserisci codice_catalogo", "int", true);*/
				String param2 = Utility.readLine("Inserisci Descrizione articolo", "varchar(400)", true);
				String param3 = Utility.readLine("Inserisci Prezzo articolo", "double", true);
				String param4 = Utility.readLine("Inserisci Nome articolo", "varchar(250)", true);
				String param5 = Utility.readLine("Inserisci tipologia_articoli", "varchar(250)", true);
				utente utente=new utente();
				
			/*	utente.setCodice_catalogo(Integer.valueOf(param1));*/
				utente.setDescrizione_articoli(param2);
				utente.setCosto(Double.valueOf(param3));
				utente.setNomi_articoli(param4);
				utente.setTipologia_articoli(param5);
				
				
			/*	String param6 = Utility.readLine("Inserisci Partita_Iva", "varchar(11)", true);
				utente.setPartita_iva(param6);*/
				
				this.inserisci_articolo(utente);
				this.sono_forniti_da(utente);
				break;
				
				
			}
			
			case 13:{
				System.out.println("Inserimento di un nuovo fornitore");
				String param1 = Utility.readLine("Inserisci nome nuovo Fornitore", "varchar (25)", true);
				String param2 = Utility.readLine("Inserisci Indirizzo fornitore", "varchar(400)", true);
				String param3 = Utility.readLine("Inserisci Partita Iva", "varchar(11)", true);
				fornitore fornitore=new fornitore();
				
				fornitore.setNome_fornitore(param1);
				fornitore.setIndirizzo(param2);
				fornitore.setPartita_iva(param3);
				
				/*String param4=Utility.readLine("Inserisci codice catalogo", "int(11)", true);*/
				String param5=Utility.readLine("Inserisci Descrizione Articolo", "varchar(400)", true);
				String param6=Utility.readLine("Inserisci Prezzo", "double", true);
				String param7=Utility.readLine("Inserisci Nome Articolo", "varchar(400)", true);
				String param8=Utility.readLine("Inserisci Tipologia Articolo", "varchar(400)", true);
				
				
				utente utente=new utente();
				
				/*utente.setCodice_catalogo(Integer.valueOf(param4));*/
				utente.setDescrizione_articoli(param5);
				utente.setCosto(Double.valueOf(param6));
				utente.setNomi_articoli(param7);
				utente.setTipologia_articoli(param8);
				
				
				
				this.inserisci_FORNITORE(fornitore);
				this.inserisci_articoloFornitore(utente);
				this.sono_forniti_da_fornitore(utente);
				break;
				
				
			}
			case 14:{
				System.out.println("Seleziona tutti gli indirizzi inseriti nella rubrica indirizzi con l�informazione su quale email utente � assoociata");
				this.OPERAZIONE_14();
				break;
			}
			
			case 15: {
				
				System.out.println("Cancella ordine");
				String param1 = Utility.readLine("numero_ordine", null, true);
				
				this.delete(param1);
				
			}
			
			case 16:{
				System.out.println("Cancella tutti gli ordini di 1 utente,inserendo la sua email");
				String param1 = Utility.readLine("EMAIL", null, true);
				
				this.delete_WITH_EMAIL(param1);
				
			}
			case 17:{
				System.out.println("Elenca nome delle citt� che non hanno ancora utenti registrati");
				this.OPERAZIONE_17();
				break;
				
			}
			case 1000: {
				System.out.println("Uscita");
				break;
			}
			default: {
				System.out.println("Scelta non presente");
				break;
			}
			} // fine switch
		} // fine while
	} // fine main

	public static void main(String[] args) throws NoSuchAlgorithmException, SQLException {
		gameshop db = new gameshop();
		System.out.println("*** Gameshop ***");
		db.testConnection();

		try {
			db.ui();
		} catch (IOException e) {
		}

		db.release();
	}

}
