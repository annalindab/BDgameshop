import java.util.Date;

public class utente {

	int id_utente;
	int id_città;
	String telefono1;
	String telefono2;
	String email;
	String nome;
	String nome_indirizzo;
	String cognome;
	Integer codice_catalogo;
	String password;
	String indirizzo;
	Integer codice_articoli;
	Integer numero_ordine;
	Integer quantità;
	Date 	data_spedizione;
	Date data_fatturazione;
	double costo;
	
	String nomi_articoli;
	String descrizione_articoli;
	Integer numero_articoli;
	Integer importo_totale;
	double importo_pagamento;
	String numero_dicarta;
	String dati_intestatario;
	Integer id_pagamento;
	Integer articoli;
	String tipologia_articoli;
	
	
	public int getId() {
		return id_utente;
	}
	
	public int getId_pagamento() {
		return id_pagamento;
	}
	
	public int getImporto_totale() {
		return importo_totale;
	}
	
	public double getCosto() {
		return costo;
	}
	
	public double getImporto_pagamento() {
		return importo_pagamento;
	}
	public int getId_città() {
		return id_città;
	}
	public int getCodice_articoli() {
		return codice_articoli;
	}
	
	public void setCosto(double i) {
		this.costo = i;
	}
	
	public void setPagamento(double i) {
		this.importo_pagamento = i;
	}
	public void setCodice_articoli(int i) {
		this.codice_articoli = i;
	}
	public void setId_pagamento(int i) {
		this.id_pagamento=i;
	}
	
	public void setImporto_pagamento(double i) {
		this.importo_pagamento = i;
	}
	public void setImporto_totale(int i) {
		this.importo_totale = i;
	}
	public Date getData_spedizione() {
		return data_spedizione;
	}
	public Date getData_fatturazione() {
		return data_fatturazione;
	}
	public void setData_fatturazione(Date data_fatturazione) {
		this.data_fatturazione = data_fatturazione;
	}
	public void setDataSpedizione(Date data_spedizione) {
		this.data_spedizione = data_spedizione;
	}
	public int getNumero_ordine() {
		return numero_ordine;
	}
	public int getQuantità() {
		return quantità;
	}
	
	public int getArticoli() {
		return articoli;
	}
	public void setArticoli(int i) {
		this.articoli=i;
	}
	public void setQuantità(int i) {
		this.quantità = i;
	}
	public void setNumero_ordine(int i) {
		this.numero_ordine = i;
	}
	public void setId_città(int i) {
		this.id_città = i;
	}
	public void setId(int i) {
		this.id_utente = i;
	}
	public String getNome() {
		return nome;
	}
	public String getTipologia_articoli() {
		return tipologia_articoli;
	}
	
	public void setTipologia_articoli(String tipologia_articoli) {
		 this.tipologia_articoli=tipologia_articoli;
	}
	
	public String getNumero_dicarta() {
		return numero_dicarta;
	
	}
	public String getdati_intestatario() {
		return dati_intestatario;
	
	}
	
	public void setdati_intestatario(String dati_intestatario) {
		this.dati_intestatario=dati_intestatario;
	}
	public void setNumero_dicarta(String numero_dicarta) {
		this.numero_dicarta=numero_dicarta;
	}
	public String getNomi_articoli() {
		return nomi_articoli;
	}
	
	public int getNumero_articoli() {
		return numero_articoli;
	}
	public void setNumero_articoli(int articoli) {
		this.numero_articoli = articoli;
	}
	
	public void setNomi_articoli(String nomi_articoli) {
		this.nomi_articoli=nomi_articoli;
	}
	public void setDescrizione_articoli(String descrizione_articoli) {
		this.descrizione_articoli=descrizione_articoli;
	}
	
	public String getDescrizione_articoli() {
		return descrizione_articoli;
	}
	
	
	public String getNome_indirizzo() {
		return nome_indirizzo;
	}
	public String getCognome() {
		return cognome;
	}
	
	public String get_telefono1() {
		return telefono1;
	}
	
	public String get_telefono2() {
		return telefono2;
	}
	
	
	public void setTelefono1(String i) {
		this.telefono1 = i;
	}
	
	public void setTelefono2(String i) {
		this.telefono2 = i;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setNome_indirizzo(String nome_indirizzo) {
		this.nome_indirizzo = nome_indirizzo;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public String getIndirizzo() {
		return indirizzo;
	}
	
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}

	public Integer getCodice_Catalogo() {
		return codice_catalogo;
	}

	public void setCodice_catalogo(Integer codice_catalogo) {
		this.codice_catalogo = codice_catalogo;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}







/*public void print_fornitori() {
	System.out.printf("%5s           | %-25s | %-30s| %4s \n", codice_articoli, nome, indirizzo, partita_iva);
}

public static void printTitle_fornitori() {
	System.out.printf("%5s | %-25s | %-30s| %-4s \n", "codice_articoli", "nome", "indirizzo", "partita_iva");
	System.out.println("----------------+---------------------------+-------------------------------+---------------");
}
*/

public void print_op9() {
	System.out.printf("%25s | %-40s \n", nomi_articoli, descrizione_articoli);
}

public static void printTitle_op9() {
	System.out.printf("%30s  | %-80s \n", "nomi_articoli", "descrizione_articoli");
	System.out.println("--------------------------------+-------------------------------------------------------------------------------------------------------------------------------");
}

public void print_op10() {
	System.out.printf("%-15s | %-20s | %-10s | %-10s |%-42s| %4d \n", nome, cognome, telefono1, telefono2, email,numero_articoli);
}

public static void printTitle_op10() {
	System.out.printf("%-15s | %-20s | %-10s | %-10s |%-42s|%-4S \n", "nome", "cognome", "telefono1", "telefono2", "email","numero_articoli");
	System.out.println("----------------+----------------------+------------+------------+------------------------------------------+-------------------------");
}

public void print_op11() {
	System.out.printf("%-15s | %-20s | %-40s | %-10d    | %4d \n", nome, cognome, email, numero_ordine, articoli);
}

public static void printTitle_op11() {
	System.out.printf("%-15s | %-20s | %-40s | %-10s |   %4S \n", "nome", "cognome", "email", "numero_ordine", "numero_articoli");
	System.out.println("----------------+----------------------+------------------------------------------+---------------+-----------------------------------");
}

public void print_op14() {
	System.out.printf("%-40s | %-41s | %-40s| %-10s \n", email, nome, cognome, indirizzo);
}

public static void printTitle_op14() {
	System.out.printf("%-40s | %-20s | %-40s| %-10s \n", "email_utente", "nome_impostato_per_indirizzo_destinatario", "cognome_per_indirizzo_destinatario", "indirizzo_impostato_nella_rubrica");
	System.out.println("-----------------------------------------+-------------------------------------------+-----------------------------------------+------------------------------------");
}

public void print_op17() {
	System.out.printf("%-15s \n", nome);
}

public static void printTitle_op17() {
	System.out.printf("%-15s \n", "nome_citt�");
	System.out.println("-----------------");
}

}
	

	
