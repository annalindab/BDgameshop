
public class fornitore {
	String nome;
	String partita_iva;
	String indirizzo;
	Integer id_fornitore;
	Integer codice_articoli;
	
	
	public String getNome_fornitore() {
		return nome;
	
	}
	
	public void setNome_fornitore(String nome) {
		this.nome=nome;
	}
	public String getPartita_Iva() {
		return partita_iva;
	
	}
	
	public Integer getId_fornitore() {
		return id_fornitore;
	
	}
	
	public void setId_fornitore(Integer id_fornitore) {
		this.id_fornitore=id_fornitore;
	}
	
	public void setCodice_articoli(Integer codice_articoli) {
		this.codice_articoli=codice_articoli;
	}
	
	public void setPartita_iva(String partita_iva) {
		this.partita_iva=partita_iva;
	}
	
	
	
	public String getIndirizzo() {
		return indirizzo;
	}
	
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	
	
	
	public void print_fornitori() {
		System.out.printf("%5s           | %-25s | %-30s| %4s \n", codice_articoli, nome, indirizzo, partita_iva);
	}

	public static void printTitle_fornitori() {
		System.out.printf("%5s | %-25s | %-30s| %-4s \n", "codice_articoli", "nome", "indirizzo", "partita_iva");
		System.out.println("----------------+---------------------------+-------------------------------+---------------");
	}
}


